import java.awt.Color;
import java.awt.Graphics2D;
import java.util.*;

public class Game {
	public Game(GameBoard board) {

	}

	public void update(Keyboard keyboard) {

	}

	public void draw(Graphics2D graphics) {

	}
}
